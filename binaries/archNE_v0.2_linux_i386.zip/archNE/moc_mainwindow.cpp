/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created: Fri Jun 10 15:20:27 2011
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../archNE/mainwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MainWindow[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
      63,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      46,       // signalCount

 // signals: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x05,
      32,   11,   11,   11, 0x05,
      44,   11,   11,   11, 0x05,
      65,   11,   11,   11, 0x05,
      85,   11,   11,   11, 0x05,
     109,  103,   11,   11, 0x05,
     157,  140,   11,   11, 0x05,
     194,   11,   11,   11, 0x05,
     215,   11,   11,   11, 0x05,
     246,  231,   11,   11, 0x05,
     267,   11,   11,   11, 0x05,
     281,   11,   11,   11, 0x05,
     290,   11,   11,   11, 0x05,
     312,  303,   11,   11, 0x05,
     341,  303,   11,   11, 0x05,
     369,   11,   11,   11, 0x05,
     387,   11,   11,   11, 0x05,
     405,   11,   11,   11, 0x05,
     418,   11,   11,   11, 0x05,
     434,   11,   11,   11, 0x05,
     450,   11,   11,   11, 0x05,
     464,   11,   11,   11, 0x05,
     486,   11,   11,   11, 0x05,
     507,   11,   11,   11, 0x05,
     524,   11,   11,   11, 0x05,
     537,   11,   11,   11, 0x05,
     551,   11,   11,   11, 0x05,
     565,   11,   11,   11, 0x05,
     598,  588,   11,   11, 0x05,
     619,   11,   11,   11, 0x05,
     642,   11,   11,   11, 0x05,
     659,   11,   11,   11, 0x05,
     666,   11,   11,   11, 0x05,
     675,   11,   11,   11, 0x05,
     699,   11,   11,   11, 0x05,
     716,   11,   11,   11, 0x05,
     734,   11,   11,   11, 0x05,
     754,   11,   11,   11, 0x05,
     772,   11,   11,   11, 0x05,
     792,   11,   11,   11, 0x05,
     814,   11,   11,   11, 0x05,
     833,   11,   11,   11, 0x05,
     852,   11,   11,   11, 0x05,
     866,   11,   11,   11, 0x05,
     886,   11,   11,   11, 0x05,
     902,   11,   11,   11, 0x05,

 // slots: signature, parameters, type, tag, flags
     919,   11,   11,   11, 0x08,
     927,   11,   11,   11, 0x08,
     956,  949,   11,   11, 0x08,
    1000,  989,   11,   11, 0x08,
    1032,   11,   11,   11, 0x0a,
    1046,   11,   11,   11, 0x0a,
    1056,   11,   11,   11, 0x0a,
    1075,   11,   11,   11, 0x0a,
    1096,   11,   11,   11, 0x0a,
    1124,   11,   11,   11, 0x0a,
    1140,   11,   11,   11, 0x0a,
    1163,   11,   11,   11, 0x0a,
    1176,   11,   11,   11, 0x0a,
    1196,   11,   11,   11, 0x0a,
    1232, 1224,   11,   11, 0x0a,
    1264, 1253,   11,   11, 0x0a,
    1294,   11,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MainWindow[] = {
    "MainWindow\0\0addSegmentPressed()\0"
    "BCPressed()\0bendSegmentPressed()\0"
    "blockNodesPressed()\0caseInfoPressed()\0"
    "event\0closeEventSignal(QCloseEvent*)\0"
    "theFName,theWDir\0currentFNameAndWDir(QString,QString)\0"
    "defaultMeshPressed()\0dockClosedSig()\0"
    "editingElement\0editingEl2Ws(QPoint)\0"
    "goCustomize()\0goMesh()\0goSimulate()\0"
    "fileName\0graphToBeCustomized(QString)\0"
    "graphToBeSimulated(QString)\0"
    "homeViewPressed()\0importBCPressed()\0"
    "importMesh()\0importNetwork()\0"
    "importResults()\0infoPressed()\0"
    "loadGraphFromLayout()\0loadGraphFromGraph()\0"
    "meshToBeLoaded()\0newNetwork()\0"
    "openNetwork()\0redoPressed()\0"
    "removeSegmentPressed()\0theResult\0"
    "resultToDisplay(int)\0resultsDockClosedSig()\0"
    "resultsPressed()\0save()\0saveAs()\0"
    "selectElementsPressed()\0setPrefPressed()\0"
    "showGridPressed()\0showLabelsPressed()\0"
    "showMeshPressed()\0snapToGridPressed()\0"
    "splitSegmentPressed()\0superEdgePressed()\0"
    "translatePressed()\0undoPressed()\0"
    "unravelNetPressed()\0zoomInPressed()\0"
    "zoomOutPressed()\0about()\0documentWasModified()\0"
    "hitEls\0elementsBeenHit(QVector<QPoint>)\0"
    "hitMeshEls\0meshElsBeenHit(QVector<QPoint>)\0"
    "restoreCurs()\0setCurs()\0updateMainWindow()\0"
    "mouseEnteredInDock()\0mouseEnteredInResultsDock()\0"
    "mouseLeftDock()\0mouseLeftResultsDock()\0"
    "dockClosed()\0resultsDockClosed()\0"
    "resultsTabsContentChanged()\0theName\0"
    "setFileName(QString)\0theMessage\0"
    "showStatusBarMessage(QString)\0"
    "tabsContentChanged()\0"
};

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow,
      qt_meta_data_MainWindow, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MainWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: addSegmentPressed(); break;
        case 1: BCPressed(); break;
        case 2: bendSegmentPressed(); break;
        case 3: blockNodesPressed(); break;
        case 4: caseInfoPressed(); break;
        case 5: closeEventSignal((*reinterpret_cast< QCloseEvent*(*)>(_a[1]))); break;
        case 6: currentFNameAndWDir((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 7: defaultMeshPressed(); break;
        case 8: dockClosedSig(); break;
        case 9: editingEl2Ws((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 10: goCustomize(); break;
        case 11: goMesh(); break;
        case 12: goSimulate(); break;
        case 13: graphToBeCustomized((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 14: graphToBeSimulated((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 15: homeViewPressed(); break;
        case 16: importBCPressed(); break;
        case 17: importMesh(); break;
        case 18: importNetwork(); break;
        case 19: importResults(); break;
        case 20: infoPressed(); break;
        case 21: loadGraphFromLayout(); break;
        case 22: loadGraphFromGraph(); break;
        case 23: meshToBeLoaded(); break;
        case 24: newNetwork(); break;
        case 25: openNetwork(); break;
        case 26: redoPressed(); break;
        case 27: removeSegmentPressed(); break;
        case 28: resultToDisplay((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 29: resultsDockClosedSig(); break;
        case 30: resultsPressed(); break;
        case 31: save(); break;
        case 32: saveAs(); break;
        case 33: selectElementsPressed(); break;
        case 34: setPrefPressed(); break;
        case 35: showGridPressed(); break;
        case 36: showLabelsPressed(); break;
        case 37: showMeshPressed(); break;
        case 38: snapToGridPressed(); break;
        case 39: splitSegmentPressed(); break;
        case 40: superEdgePressed(); break;
        case 41: translatePressed(); break;
        case 42: undoPressed(); break;
        case 43: unravelNetPressed(); break;
        case 44: zoomInPressed(); break;
        case 45: zoomOutPressed(); break;
        case 46: about(); break;
        case 47: documentWasModified(); break;
        case 48: elementsBeenHit((*reinterpret_cast< QVector<QPoint>(*)>(_a[1]))); break;
        case 49: meshElsBeenHit((*reinterpret_cast< QVector<QPoint>(*)>(_a[1]))); break;
        case 50: restoreCurs(); break;
        case 51: setCurs(); break;
        case 52: updateMainWindow(); break;
        case 53: mouseEnteredInDock(); break;
        case 54: mouseEnteredInResultsDock(); break;
        case 55: mouseLeftDock(); break;
        case 56: mouseLeftResultsDock(); break;
        case 57: dockClosed(); break;
        case 58: resultsDockClosed(); break;
        case 59: resultsTabsContentChanged(); break;
        case 60: setFileName((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 61: showStatusBarMessage((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 62: tabsContentChanged(); break;
        default: ;
        }
        _id -= 63;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::addSegmentPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void MainWindow::BCPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void MainWindow::bendSegmentPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}

// SIGNAL 3
void MainWindow::blockNodesPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 3, 0);
}

// SIGNAL 4
void MainWindow::caseInfoPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 4, 0);
}

// SIGNAL 5
void MainWindow::closeEventSignal(QCloseEvent * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void MainWindow::currentFNameAndWDir(QString _t1, QString _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void MainWindow::defaultMeshPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 7, 0);
}

// SIGNAL 8
void MainWindow::dockClosedSig()
{
    QMetaObject::activate(this, &staticMetaObject, 8, 0);
}

// SIGNAL 9
void MainWindow::editingEl2Ws(QPoint _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void MainWindow::goCustomize()
{
    QMetaObject::activate(this, &staticMetaObject, 10, 0);
}

// SIGNAL 11
void MainWindow::goMesh()
{
    QMetaObject::activate(this, &staticMetaObject, 11, 0);
}

// SIGNAL 12
void MainWindow::goSimulate()
{
    QMetaObject::activate(this, &staticMetaObject, 12, 0);
}

// SIGNAL 13
void MainWindow::graphToBeCustomized(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}

// SIGNAL 14
void MainWindow::graphToBeSimulated(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 14, _a);
}

// SIGNAL 15
void MainWindow::homeViewPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 15, 0);
}

// SIGNAL 16
void MainWindow::importBCPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 16, 0);
}

// SIGNAL 17
void MainWindow::importMesh()
{
    QMetaObject::activate(this, &staticMetaObject, 17, 0);
}

// SIGNAL 18
void MainWindow::importNetwork()
{
    QMetaObject::activate(this, &staticMetaObject, 18, 0);
}

// SIGNAL 19
void MainWindow::importResults()
{
    QMetaObject::activate(this, &staticMetaObject, 19, 0);
}

// SIGNAL 20
void MainWindow::infoPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 20, 0);
}

// SIGNAL 21
void MainWindow::loadGraphFromLayout()
{
    QMetaObject::activate(this, &staticMetaObject, 21, 0);
}

// SIGNAL 22
void MainWindow::loadGraphFromGraph()
{
    QMetaObject::activate(this, &staticMetaObject, 22, 0);
}

// SIGNAL 23
void MainWindow::meshToBeLoaded()
{
    QMetaObject::activate(this, &staticMetaObject, 23, 0);
}

// SIGNAL 24
void MainWindow::newNetwork()
{
    QMetaObject::activate(this, &staticMetaObject, 24, 0);
}

// SIGNAL 25
void MainWindow::openNetwork()
{
    QMetaObject::activate(this, &staticMetaObject, 25, 0);
}

// SIGNAL 26
void MainWindow::redoPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 26, 0);
}

// SIGNAL 27
void MainWindow::removeSegmentPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 27, 0);
}

// SIGNAL 28
void MainWindow::resultToDisplay(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 28, _a);
}

// SIGNAL 29
void MainWindow::resultsDockClosedSig()
{
    QMetaObject::activate(this, &staticMetaObject, 29, 0);
}

// SIGNAL 30
void MainWindow::resultsPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 30, 0);
}

// SIGNAL 31
void MainWindow::save()
{
    QMetaObject::activate(this, &staticMetaObject, 31, 0);
}

// SIGNAL 32
void MainWindow::saveAs()
{
    QMetaObject::activate(this, &staticMetaObject, 32, 0);
}

// SIGNAL 33
void MainWindow::selectElementsPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 33, 0);
}

// SIGNAL 34
void MainWindow::setPrefPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 34, 0);
}

// SIGNAL 35
void MainWindow::showGridPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 35, 0);
}

// SIGNAL 36
void MainWindow::showLabelsPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 36, 0);
}

// SIGNAL 37
void MainWindow::showMeshPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 37, 0);
}

// SIGNAL 38
void MainWindow::snapToGridPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 38, 0);
}

// SIGNAL 39
void MainWindow::splitSegmentPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 39, 0);
}

// SIGNAL 40
void MainWindow::superEdgePressed()
{
    QMetaObject::activate(this, &staticMetaObject, 40, 0);
}

// SIGNAL 41
void MainWindow::translatePressed()
{
    QMetaObject::activate(this, &staticMetaObject, 41, 0);
}

// SIGNAL 42
void MainWindow::undoPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 42, 0);
}

// SIGNAL 43
void MainWindow::unravelNetPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 43, 0);
}

// SIGNAL 44
void MainWindow::zoomInPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 44, 0);
}

// SIGNAL 45
void MainWindow::zoomOutPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 45, 0);
}
QT_END_MOC_NAMESPACE
