/********************************************************************************
** Form generated from reading UI file 'infodialog.ui'
**
** Created: Fri Jun 10 15:19:11 2011
**      by: Qt User Interface Compiler version 4.7.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INFODIALOG_H
#define UI_INFODIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_InfoDialog
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *infoLabel;
    QLabel *advanceLabel;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *abortButton;

    void setupUi(QWidget *InfoDialog)
    {
        if (InfoDialog->objectName().isEmpty())
            InfoDialog->setObjectName(QString::fromUtf8("InfoDialog"));
        InfoDialog->setWindowModality(Qt::ApplicationModal);
        InfoDialog->resize(285, 148);
        verticalLayout = new QVBoxLayout(InfoDialog);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        infoLabel = new QLabel(InfoDialog);
        infoLabel->setObjectName(QString::fromUtf8("infoLabel"));

        verticalLayout->addWidget(infoLabel);

        advanceLabel = new QLabel(InfoDialog);
        advanceLabel->setObjectName(QString::fromUtf8("advanceLabel"));
        advanceLabel->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(advanceLabel);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(98, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        abortButton = new QPushButton(InfoDialog);
        abortButton->setObjectName(QString::fromUtf8("abortButton"));

        horizontalLayout->addWidget(abortButton);


        verticalLayout->addLayout(horizontalLayout);


        retranslateUi(InfoDialog);
        QObject::connect(abortButton, SIGNAL(released()), InfoDialog, SLOT(abortButtonReleased()));

        QMetaObject::connectSlotsByName(InfoDialog);
    } // setupUi

    void retranslateUi(QWidget *InfoDialog)
    {
        InfoDialog->setWindowTitle(QApplication::translate("InfoDialog", "Info", 0, QApplication::UnicodeUTF8));
        infoLabel->setText(QApplication::translate("InfoDialog", "TextLabel", 0, QApplication::UnicodeUTF8));
        advanceLabel->setText(QApplication::translate("InfoDialog", "TextLabel", 0, QApplication::UnicodeUTF8));
        abortButton->setText(QApplication::translate("InfoDialog", "Abort simulation", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class InfoDialog: public Ui_InfoDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INFODIALOG_H
