/****************************************************************************
** Meta object code from reading C++ file 'graphproperties.h'
**
** Created: Fri Jun 10 15:20:24 2011
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../archNE/graphproperties.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'graphproperties.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_GraphProperties[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      24,   17,   16,   16, 0x0a,
      56,   49,   16,   16, 0x0a,
      96,   81,   16,   16, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_GraphProperties[] = {
    "GraphProperties\0\0nodeId\0"
    "deleteNodeFromGraph(int)\0edgeId\0"
    "deleteEdgeFromGraph(int)\0edgeId,theType\0"
    "setEdgeType(int,QString)\0"
};

const QMetaObject GraphProperties::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_GraphProperties,
      qt_meta_data_GraphProperties, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &GraphProperties::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *GraphProperties::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *GraphProperties::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_GraphProperties))
        return static_cast<void*>(const_cast< GraphProperties*>(this));
    return QObject::qt_metacast(_clname);
}

int GraphProperties::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: deleteNodeFromGraph((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: deleteEdgeFromGraph((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: setEdgeType((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        default: ;
        }
        _id -= 3;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
