/********************************************************************************
** Form generated from reading UI file 'resultsview.ui'
**
** Created: Fri Jun 10 15:19:11 2011
**      by: Qt User Interface Compiler version 4.7.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RESULTSVIEW_H
#define UI_RESULTSVIEW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QSplitter>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ResultsView
{
public:
    QVBoxLayout *verticalLayout_4;
    QVBoxLayout *verticalLayout_3;
    QSplitter *splitter;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *pressureLabel;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout_2;
    QLabel *flowLabel;
    QDialogButtonBox *buttonBox;

    void setupUi(QWidget *ResultsView)
    {
        if (ResultsView->objectName().isEmpty())
            ResultsView->setObjectName(QString::fromUtf8("ResultsView"));
        ResultsView->resize(400, 202);
        ResultsView->setMinimumSize(QSize(0, 0));
        verticalLayout_4 = new QVBoxLayout(ResultsView);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        splitter = new QSplitter(ResultsView);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Vertical);
        splitter->setOpaqueResize(true);
        splitter->setChildrenCollapsible(false);
        layoutWidget = new QWidget(splitter);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pressureLabel = new QLabel(layoutWidget);
        pressureLabel->setObjectName(QString::fromUtf8("pressureLabel"));
        pressureLabel->setScaledContents(false);

        verticalLayout->addWidget(pressureLabel);

        splitter->addWidget(layoutWidget);
        layoutWidget1 = new QWidget(splitter);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        verticalLayout_2 = new QVBoxLayout(layoutWidget1);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        flowLabel = new QLabel(layoutWidget1);
        flowLabel->setObjectName(QString::fromUtf8("flowLabel"));
        flowLabel->setScaledContents(false);

        verticalLayout_2->addWidget(flowLabel);

        splitter->addWidget(layoutWidget1);

        verticalLayout_3->addWidget(splitter);


        verticalLayout_4->addLayout(verticalLayout_3);

        buttonBox = new QDialogButtonBox(ResultsView);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setStandardButtons(QDialogButtonBox::Ok);

        verticalLayout_4->addWidget(buttonBox);


        retranslateUi(ResultsView);
        QObject::connect(buttonBox, SIGNAL(accepted()), ResultsView, SLOT(okButtClicked()));

        QMetaObject::connectSlotsByName(ResultsView);
    } // setupUi

    void retranslateUi(QWidget *ResultsView)
    {
        ResultsView->setWindowTitle(QApplication::translate("ResultsView", "Form", 0, QApplication::UnicodeUTF8));
        pressureLabel->setText(QApplication::translate("ResultsView", "TextLabel", 0, QApplication::UnicodeUTF8));
        flowLabel->setText(QApplication::translate("ResultsView", "TextLabel", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class ResultsView: public Ui_ResultsView {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RESULTSVIEW_H
