/****************************************************************************
** Meta object code from reading C++ file 'workspace.h'
**
** Created: Fri Jun 10 15:20:34 2011
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../archNE/workspace.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'workspace.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_Workspace[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
      39,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: signature, parameters, type, tag, flags
      11,   10,   10,   10, 0x05,
      25,   10,   10,   10, 0x05,
      40,   10,   10,   10, 0x05,
      73,   58,   10,   10, 0x05,
      93,   10,   10,   10, 0x05,
     108,   58,   10,   10, 0x05,

 // slots: signature, parameters, type, tag, flags
     128,   10,   10,   10, 0x0a,
     141,   10,   10,   10, 0x0a,
     160,   10,   10,   10, 0x0a,
     174,   10,   10,   10, 0x0a,
     187,   10,   10,   10, 0x0a,
     198,   10,   10,   10, 0x0a,
     205,   10,   10,   10, 0x0a,
     238,  222,   10,   10, 0x0a,
     262,   10,   10,   10, 0x0a,
     269,   10,   10,   10, 0x0a,
     285,   10,   10,   10, 0x0a,
     302,   10,   10,   10, 0x0a,
     313,   10,   10,   10, 0x0a,
     326,   10,   10,   10, 0x0a,
     337,   10,   10,   10, 0x0a,
     350,   10,   10,   10, 0x0a,
     365,   10,   10,   10, 0x0a,
     377,   10,   10,   10, 0x0a,
     389,   10,   10,   10, 0x0a,
     400,  396,   10,   10, 0x0a,
     422,  396,   10,   10, 0x0a,
     442,  396,   10,   10, 0x0a,
     479,  465,   10,   10, 0x0a,
     516,  500,   10,   10, 0x0a,
     553,  541,   10,   10, 0x0a,
     575,   10,   10,   10, 0x0a,
     591,   10,   10,   10, 0x0a,
     612,   10,   10,   10, 0x0a,
     645,  633,   10,   10, 0x0a,
     691,  678,   10,   10, 0x0a,
     723,   10,   10,   10, 0x0a,
     743,   10,   10,   10, 0x0a,
     764,  756,   10,   10, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_Workspace[] = {
    "Workspace\0\0restoreCurs()\0updateSignal()\0"
    "contentsChanged()\0elementRequest\0"
    "dataRequest(QPoint)\0noMeshHitEls()\0"
    "showResults(QPoint)\0addSegment()\0"
    "applyDefaultMesh()\0bendSegment()\0"
    "blockNodes()\0homeView()\0info()\0"
    "resultsRequest()\0theResToDisplay\0"
    "setResultToDisplay(int)\0redo()\0"
    "removeSegment()\0selectElements()\0"
    "showGrid()\0showLabels()\0showMesh()\0"
    "snapToGrid()\0splitSegment()\0superEdge()\0"
    "translate()\0undo()\0pos\0mousePressed(QPointF)\0"
    "mouseMoved(QPointF)\0mouseReleased(QPointF)\0"
    "theZoomFactor\0setZoomFactor(float)\0"
    "theScreenOrigin\0setScreenOrigin(QPointF)\0"
    "shiftStatus\0setShiftPressed(bool)\0"
    "updateHistory()\0Key_Cancel_Pressed()\0"
    "Key_CTRL_A_Pressed()\0hitElements\0"
    "elementsBeenHit(QVector<QPoint>)\0"
    "theHitMesEls\0meshElsBeenHit(QVector<QPoint>)\0"
    "netToBeUnravelled()\0unravelNet()\0"
    "element\0setHighlightingEl(QPoint)\0"
};

const QMetaObject Workspace::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_Workspace,
      qt_meta_data_Workspace, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Workspace::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Workspace::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Workspace::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Workspace))
        return static_cast<void*>(const_cast< Workspace*>(this));
    return QObject::qt_metacast(_clname);
}

int Workspace::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: restoreCurs(); break;
        case 1: updateSignal(); break;
        case 2: contentsChanged(); break;
        case 3: dataRequest((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 4: noMeshHitEls(); break;
        case 5: showResults((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 6: addSegment(); break;
        case 7: applyDefaultMesh(); break;
        case 8: bendSegment(); break;
        case 9: blockNodes(); break;
        case 10: homeView(); break;
        case 11: info(); break;
        case 12: resultsRequest(); break;
        case 13: setResultToDisplay((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: redo(); break;
        case 15: removeSegment(); break;
        case 16: selectElements(); break;
        case 17: showGrid(); break;
        case 18: showLabels(); break;
        case 19: showMesh(); break;
        case 20: snapToGrid(); break;
        case 21: splitSegment(); break;
        case 22: superEdge(); break;
        case 23: translate(); break;
        case 24: undo(); break;
        case 25: mousePressed((*reinterpret_cast< QPointF(*)>(_a[1]))); break;
        case 26: mouseMoved((*reinterpret_cast< QPointF(*)>(_a[1]))); break;
        case 27: mouseReleased((*reinterpret_cast< QPointF(*)>(_a[1]))); break;
        case 28: setZoomFactor((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 29: setScreenOrigin((*reinterpret_cast< QPointF(*)>(_a[1]))); break;
        case 30: setShiftPressed((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 31: updateHistory(); break;
        case 32: Key_Cancel_Pressed(); break;
        case 33: Key_CTRL_A_Pressed(); break;
        case 34: elementsBeenHit((*reinterpret_cast< QVector<QPoint>(*)>(_a[1]))); break;
        case 35: meshElsBeenHit((*reinterpret_cast< QVector<QPoint>(*)>(_a[1]))); break;
        case 36: netToBeUnravelled(); break;
        case 37: unravelNet(); break;
        case 38: setHighlightingEl((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 39;
    }
    return _id;
}

// SIGNAL 0
void Workspace::restoreCurs()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void Workspace::updateSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void Workspace::contentsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}

// SIGNAL 3
void Workspace::dataRequest(QPoint _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void Workspace::noMeshHitEls()
{
    QMetaObject::activate(this, &staticMetaObject, 4, 0);
}

// SIGNAL 5
void Workspace::showResults(QPoint _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}
QT_END_MOC_NAMESPACE
