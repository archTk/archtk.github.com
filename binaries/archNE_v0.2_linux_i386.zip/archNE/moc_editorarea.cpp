/****************************************************************************
** Meta object code from reading C++ file 'editorarea.h'
**
** Created: Fri Jun 10 15:20:20 2011
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../archNE/editorarea.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'editorarea.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_EditorArea[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
      20,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      13,       // signalCount

 // signals: signature, parameters, type, tag, flags
      21,   12,   11,   11, 0x05,
      47,   12,   11,   11, 0x05,
      67,   12,   11,   11, 0x05,
     101,   90,   11,   11, 0x05,
     139,  126,   11,   11, 0x05,
     180,  168,   11,   11, 0x05,
     206,   11,   11,   11, 0x05,
     222,   11,   11,   11, 0x05,
     241,   11,   11,   11, 0x05,
     262,   11,   11,   11, 0x05,
     278,   11,   11,   11, 0x05,
     311,  299,   11,   11, 0x05,
     355,  344,   11,   11, 0x05,

 // slots: signature, parameters, type, tag, flags
     387,   11,   11,   11, 0x0a,
     398,   11,   11,   11, 0x0a,
     413,   11,   11,   11, 0x0a,
     422,   11,   11,   11, 0x0a,
     432,   11,   11,   11, 0x0a,
     446,   11,   11,   11, 0x0a,
     478,  468,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_EditorArea[] = {
    "EditorArea\0\0validPos\0mouseBeenPressed(QPointF)\0"
    "mouseMoved(QPointF)\0mouseReleased(QPointF)\0"
    "zoomFactor\0zoomFactorChanged(float)\0"
    "screenOrigin\0screenOriginChanged(QPointF)\0"
    "shiftStatus\0shiftPressedChanged(bool)\0"
    "updateHistory()\0updateMainWindow()\0"
    "Key_Cancel_Pressed()\0Key_B_Pressed()\0"
    "Key_CTRL_A_Pressed()\0hitElements\0"
    "elementsBeenHit(QVector<QPoint>)\0"
    "hitMeshEls\0meshElsBeenHit(QVector<QPoint>)\0"
    "homeView()\0updateRender()\0zoomIn()\0"
    "zoomOut()\0toBeCleared()\0resetMeshElToBeHigh()\0"
    "theResult\0setResToBeDisplayed(int)\0"
};

const QMetaObject EditorArea::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_EditorArea,
      qt_meta_data_EditorArea, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &EditorArea::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *EditorArea::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *EditorArea::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_EditorArea))
        return static_cast<void*>(const_cast< EditorArea*>(this));
    return QWidget::qt_metacast(_clname);
}

int EditorArea::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: mouseBeenPressed((*reinterpret_cast< QPointF(*)>(_a[1]))); break;
        case 1: mouseMoved((*reinterpret_cast< QPointF(*)>(_a[1]))); break;
        case 2: mouseReleased((*reinterpret_cast< QPointF(*)>(_a[1]))); break;
        case 3: zoomFactorChanged((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 4: screenOriginChanged((*reinterpret_cast< QPointF(*)>(_a[1]))); break;
        case 5: shiftPressedChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: updateHistory(); break;
        case 7: updateMainWindow(); break;
        case 8: Key_Cancel_Pressed(); break;
        case 9: Key_B_Pressed(); break;
        case 10: Key_CTRL_A_Pressed(); break;
        case 11: elementsBeenHit((*reinterpret_cast< QVector<QPoint>(*)>(_a[1]))); break;
        case 12: meshElsBeenHit((*reinterpret_cast< QVector<QPoint>(*)>(_a[1]))); break;
        case 13: homeView(); break;
        case 14: updateRender(); break;
        case 15: zoomIn(); break;
        case 16: zoomOut(); break;
        case 17: toBeCleared(); break;
        case 18: resetMeshElToBeHigh(); break;
        case 19: setResToBeDisplayed((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 20;
    }
    return _id;
}

// SIGNAL 0
void EditorArea::mouseBeenPressed(QPointF _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void EditorArea::mouseMoved(QPointF _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void EditorArea::mouseReleased(QPointF _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void EditorArea::zoomFactorChanged(float _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void EditorArea::screenOriginChanged(QPointF _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void EditorArea::shiftPressedChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void EditorArea::updateHistory()
{
    QMetaObject::activate(this, &staticMetaObject, 6, 0);
}

// SIGNAL 7
void EditorArea::updateMainWindow()
{
    QMetaObject::activate(this, &staticMetaObject, 7, 0);
}

// SIGNAL 8
void EditorArea::Key_Cancel_Pressed()
{
    QMetaObject::activate(this, &staticMetaObject, 8, 0);
}

// SIGNAL 9
void EditorArea::Key_B_Pressed()
{
    QMetaObject::activate(this, &staticMetaObject, 9, 0);
}

// SIGNAL 10
void EditorArea::Key_CTRL_A_Pressed()
{
    QMetaObject::activate(this, &staticMetaObject, 10, 0);
}

// SIGNAL 11
void EditorArea::elementsBeenHit(QVector<QPoint> _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void EditorArea::meshElsBeenHit(QVector<QPoint> _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}
QT_END_MOC_NAMESPACE
