/********************************************************************************
** Form generated from reading UI file 'datacollector.ui'
**
** Created: Fri Jun 10 15:19:11 2011
**      by: Qt User Interface Compiler version 4.7.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DATACOLLECTOR_H
#define UI_DATACOLLECTOR_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QFrame>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QPlainTextEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QSplitter>
#include <QtGui/QTextEdit>
#include <QtGui/QToolBar>
#include <QtGui/QTreeView>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DataCollector
{
public:
    QAction *actionEditDom;
    QAction *actionUndo;
    QAction *actionRedo;
    QAction *actionReset;
    QAction *actionOkCombo;
    QAction *actionCancelCombo;
    QAction *actionAddChild;
    QAction *actionRemoveElement;
    QAction *actionShowDom;
    QVBoxLayout *vboxLayout;
    QSplitter *splitter;
    QTreeView *treeView;
    QPlainTextEdit *workingDomText;
    QTextEdit *detailStatusText;
    QFrame *toolbarFrame;
    QHBoxLayout *domStatusLayout;
    QToolBar *lowerToolBar;
    QHBoxLayout *buttonLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *cancelButton;
    QPushButton *applyButton;
    QPushButton *okButton;
    QSpacerItem *horizontalSpacer_2;

    void setupUi(QWidget *DataCollector)
    {
        if (DataCollector->objectName().isEmpty())
            DataCollector->setObjectName(QString::fromUtf8("DataCollector"));
        DataCollector->setStyleSheet(QString::fromUtf8("\n"
"QPlainTextEdit#workingDomText {color:#000000;border 0px solid transparent;margin:0;padding:0;background-color:#ffffbf}\n"
"QTextEdit#detailStatusText {border-radius:3px;padding-left:2px;border:0px solid #515151;background-color:#b15151}\n"
""));
        actionEditDom = new QAction(DataCollector);
        actionEditDom->setObjectName(QString::fromUtf8("actionEditDom"));
        actionEditDom->setCheckable(true);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":icons/editDom.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionEditDom->setIcon(icon);
        actionUndo = new QAction(DataCollector);
        actionUndo->setObjectName(QString::fromUtf8("actionUndo"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":icons/undo.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionUndo->setIcon(icon1);
        actionRedo = new QAction(DataCollector);
        actionRedo->setObjectName(QString::fromUtf8("actionRedo"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":icons/redo.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionRedo->setIcon(icon2);
        actionReset = new QAction(DataCollector);
        actionReset->setObjectName(QString::fromUtf8("actionReset"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":icons/reset.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionReset->setIcon(icon3);
        actionOkCombo = new QAction(DataCollector);
        actionOkCombo->setObjectName(QString::fromUtf8("actionOkCombo"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":icons/apply.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionOkCombo->setIcon(icon4);
        actionCancelCombo = new QAction(DataCollector);
        actionCancelCombo->setObjectName(QString::fromUtf8("actionCancelCombo"));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":icons/cancel.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionCancelCombo->setIcon(icon5);
        actionAddChild = new QAction(DataCollector);
        actionAddChild->setObjectName(QString::fromUtf8("actionAddChild"));
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":icons/add_child.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionAddChild->setIcon(icon6);
        actionRemoveElement = new QAction(DataCollector);
        actionRemoveElement->setObjectName(QString::fromUtf8("actionRemoveElement"));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":icons/remove_element.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionRemoveElement->setIcon(icon7);
        actionShowDom = new QAction(DataCollector);
        actionShowDom->setObjectName(QString::fromUtf8("actionShowDom"));
        actionShowDom->setCheckable(true);
        QIcon icon8;
        icon8.addFile(QString::fromUtf8(":icons/show_dom.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionShowDom->setIcon(icon8);
        vboxLayout = new QVBoxLayout(DataCollector);
        vboxLayout->setSpacing(0);
        vboxLayout->setContentsMargins(0, 0, 0, 0);
        vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));
        splitter = new QSplitter(DataCollector);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setFrameShape(QFrame::NoFrame);
        splitter->setOrientation(Qt::Vertical);
        treeView = new QTreeView(splitter);
        treeView->setObjectName(QString::fromUtf8("treeView"));
        treeView->setAlternatingRowColors(true);
        treeView->setSelectionBehavior(QAbstractItemView::SelectItems);
        treeView->setHorizontalScrollMode(QAbstractItemView::ScrollPerPixel);
        treeView->setIndentation(10);
        treeView->setAnimated(false);
        treeView->setAllColumnsShowFocus(true);
        splitter->addWidget(treeView);
        workingDomText = new QPlainTextEdit(splitter);
        workingDomText->setObjectName(QString::fromUtf8("workingDomText"));
        workingDomText->setFrameShape(QFrame::NoFrame);
        workingDomText->setLineWrapMode(QPlainTextEdit::NoWrap);
        splitter->addWidget(workingDomText);

        vboxLayout->addWidget(splitter);

        detailStatusText = new QTextEdit(DataCollector);
        detailStatusText->setObjectName(QString::fromUtf8("detailStatusText"));
        detailStatusText->setMaximumHeight(40);
        detailStatusText->setMinimumHeight(40);
        detailStatusText->setFrameShape(QFrame::NoFrame);
        QSizePolicy sizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(detailStatusText->sizePolicy().hasHeightForWidth());
        detailStatusText->setSizePolicy(sizePolicy);

        vboxLayout->addWidget(detailStatusText);

        toolbarFrame = new QFrame(DataCollector);
        toolbarFrame->setObjectName(QString::fromUtf8("toolbarFrame"));
        toolbarFrame->setMaximumHeight(40);
        toolbarFrame->setMinimumHeight(40);
        toolbarFrame->setFrameShape(QFrame::NoFrame);
        domStatusLayout = new QHBoxLayout(toolbarFrame);
        domStatusLayout->setSpacing(10);
        domStatusLayout->setContentsMargins(4, 4, 4, 4);
        domStatusLayout->setObjectName(QString::fromUtf8("domStatusLayout"));
        lowerToolBar = new QToolBar(toolbarFrame);
        lowerToolBar->setObjectName(QString::fromUtf8("lowerToolBar"));

        domStatusLayout->addWidget(lowerToolBar);


        vboxLayout->addWidget(toolbarFrame);

        buttonLayout = new QHBoxLayout();
        buttonLayout->setSpacing(0);
        buttonLayout->setContentsMargins(0, 0, 0, 0);
        buttonLayout->setObjectName(QString::fromUtf8("buttonLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        buttonLayout->addItem(horizontalSpacer);

        cancelButton = new QPushButton(DataCollector);
        cancelButton->setObjectName(QString::fromUtf8("cancelButton"));
        cancelButton->setIcon(icon5);

        buttonLayout->addWidget(cancelButton);

        applyButton = new QPushButton(DataCollector);
        applyButton->setObjectName(QString::fromUtf8("applyButton"));
        applyButton->setIcon(icon4);

        buttonLayout->addWidget(applyButton);

        okButton = new QPushButton(DataCollector);
        okButton->setObjectName(QString::fromUtf8("okButton"));
        QIcon icon9;
        icon9.addFile(QString::fromUtf8(":icons/ok.png"), QSize(), QIcon::Normal, QIcon::Off);
        okButton->setIcon(icon9);

        buttonLayout->addWidget(okButton);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        buttonLayout->addItem(horizontalSpacer_2);


        vboxLayout->addLayout(buttonLayout);


        lowerToolBar->addAction(actionShowDom);
        lowerToolBar->addAction(actionEditDom);
        lowerToolBar->addAction(actionUndo);
        lowerToolBar->addAction(actionRedo);
        lowerToolBar->addAction(actionReset);

        retranslateUi(DataCollector);

        QMetaObject::connectSlotsByName(DataCollector);
    } // setupUi

    void retranslateUi(QWidget *DataCollector)
    {
        actionEditDom->setText(QApplication::translate("DataCollector", "Edit Dom", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionEditDom->setToolTip(QApplication::translate("DataCollector", "Edit Dom", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_STATUSTIP
        actionEditDom->setStatusTip(QApplication::translate("DataCollector", "Edit Dom", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_STATUSTIP
        actionEditDom->setShortcut(QApplication::translate("DataCollector", "Alt+E", 0, QApplication::UnicodeUTF8));
        actionUndo->setText(QApplication::translate("DataCollector", "Undo", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionUndo->setToolTip(QApplication::translate("DataCollector", "Undo", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_STATUSTIP
        actionUndo->setStatusTip(QApplication::translate("DataCollector", "Undo", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_STATUSTIP
        actionUndo->setShortcut(QApplication::translate("DataCollector", "Alt+Left", 0, QApplication::UnicodeUTF8));
        actionRedo->setText(QApplication::translate("DataCollector", "Redo", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionRedo->setToolTip(QApplication::translate("DataCollector", "Redo", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_STATUSTIP
        actionRedo->setStatusTip(QApplication::translate("DataCollector", "Redo", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_STATUSTIP
        actionRedo->setShortcut(QApplication::translate("DataCollector", "Alt+Right", 0, QApplication::UnicodeUTF8));
        actionReset->setText(QApplication::translate("DataCollector", "Reset", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionReset->setToolTip(QApplication::translate("DataCollector", "Reset", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_STATUSTIP
        actionReset->setStatusTip(QApplication::translate("DataCollector", "Reset", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_STATUSTIP
        actionOkCombo->setText(QApplication::translate("DataCollector", "Ok", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionOkCombo->setToolTip(QApplication::translate("DataCollector", "Ok", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_STATUSTIP
        actionOkCombo->setStatusTip(QApplication::translate("DataCollector", "Ok", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_STATUSTIP
        actionCancelCombo->setText(QApplication::translate("DataCollector", "Cancel", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionCancelCombo->setToolTip(QApplication::translate("DataCollector", "Cancel", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_STATUSTIP
        actionCancelCombo->setStatusTip(QApplication::translate("DataCollector", "Cancel", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_STATUSTIP
        actionAddChild->setText(QApplication::translate("DataCollector", "Add Child Element", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionAddChild->setToolTip(QApplication::translate("DataCollector", "Add Child Element", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_STATUSTIP
        actionAddChild->setStatusTip(QApplication::translate("DataCollector", "Add Child Element", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_STATUSTIP
        actionRemoveElement->setText(QApplication::translate("DataCollector", "Remove Element", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionRemoveElement->setToolTip(QApplication::translate("DataCollector", "Remove Element", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_STATUSTIP
        actionRemoveElement->setStatusTip(QApplication::translate("DataCollector", "Remove Element", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_STATUSTIP
        actionShowDom->setText(QApplication::translate("DataCollector", "Show/Hide Dom", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionShowDom->setToolTip(QApplication::translate("DataCollector", "Show/Hide Dom", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_STATUSTIP
        actionShowDom->setStatusTip(QApplication::translate("DataCollector", "Show/Hide Dom", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_STATUSTIP
        cancelButton->setText(QApplication::translate("DataCollector", "Cancel", 0, QApplication::UnicodeUTF8));
        applyButton->setText(QApplication::translate("DataCollector", "Apply", 0, QApplication::UnicodeUTF8));
        okButton->setText(QApplication::translate("DataCollector", "Ok", 0, QApplication::UnicodeUTF8));
        Q_UNUSED(DataCollector);
    } // retranslateUi

};

namespace Ui {
    class DataCollector: public Ui_DataCollector {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DATACOLLECTOR_H
