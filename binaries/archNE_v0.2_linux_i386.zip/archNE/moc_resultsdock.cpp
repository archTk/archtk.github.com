/****************************************************************************
** Meta object code from reading C++ file 'resultsdock.h'
**
** Created: Fri Jun 10 15:20:30 2011
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../archNE/resultsdock.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'resultsdock.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_ResultsDock[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: signature, parameters, type, tag, flags
      13,   12,   12,   12, 0x05,
      41,   12,   12,   12, 0x05,
      64,   12,   12,   12, 0x05,

       0        // eod
};

static const char qt_meta_stringdata_ResultsDock[] = {
    "ResultsDock\0\0mouseEnteredInResultsDock()\0"
    "mouseLeftResultsDock()\0resultsDockClosed()\0"
};

const QMetaObject ResultsDock::staticMetaObject = {
    { &QDockWidget::staticMetaObject, qt_meta_stringdata_ResultsDock,
      qt_meta_data_ResultsDock, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ResultsDock::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ResultsDock::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ResultsDock::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ResultsDock))
        return static_cast<void*>(const_cast< ResultsDock*>(this));
    return QDockWidget::qt_metacast(_clname);
}

int ResultsDock::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDockWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: mouseEnteredInResultsDock(); break;
        case 1: mouseLeftResultsDock(); break;
        case 2: resultsDockClosed(); break;
        default: ;
        }
        _id -= 3;
    }
    return _id;
}

// SIGNAL 0
void ResultsDock::mouseEnteredInResultsDock()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void ResultsDock::mouseLeftResultsDock()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void ResultsDock::resultsDockClosed()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}
QT_END_MOC_NAMESPACE
