/****************************************************************************
** Meta object code from reading C++ file 'appcontroller.h'
**
** Created: Fri Jun 10 15:20:16 2011
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../archNE/appcontroller.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'appcontroller.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_AppController[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
      40,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: signature, parameters, type, tag, flags
      30,   15,   14,   14, 0x05,
      62,   51,   14,   14, 0x05,
      92,   14,   14,   14, 0x05,
     106,   14,   14,   14, 0x05,
     116,   14,   14,   14, 0x05,

 // slots: signature, parameters, type, tag, flags
     131,   14,   14,   14, 0x0a,
     149,   14,   14,   14, 0x0a,
     161,   14,   14,   14, 0x0a,
     179,   14,   14,   14, 0x0a,
     202,  196,   14,   14, 0x0a,
     234,  227,   14,   14, 0x0a,
     279,  260,   14,   14, 0x0a,
     315,  260,   14,   14, 0x0a,
     361,  346,   14,   14, 0x0a,
     381,   14,   14,   14, 0x0a,
     394,   14,   14,   14, 0x0a,
     436,   14,   14,   14, 0x0a,
     451,   14,   14,   14, 0x0a,
     463,   14,   14,   14, 0x0a,
     479,   14,   14,   14, 0x0a,
     504,   14,   14,   14, 0x0a,
     515,   14,   14,   14, 0x0a,
     528,   14,   14,   14, 0x0a,
     544,   14,   14,   14, 0x0a,
     560,   14,   14,   14, 0x0a,
     574,   14,   14,   14, 0x0a,
     588,   14,   14,   14, 0x0a,
     602,   14,   14,   14, 0x0a,
     625,   14,   14,   14, 0x0a,
     638,   14,   14,   14, 0x0a,
     652,   14,   14,   14, 0x0a,
     677,   14,  672,   14, 0x0a,
     684,   14,  672,   14, 0x0a,
     710,  693,   14,   14, 0x0a,
     743,   14,   14,   14, 0x0a,
     760,  346,   14,   14, 0x0a,
     780,   14,   14,   14, 0x0a,
     798,   14,   14,   14, 0x0a,
     816,  814,   14,   14, 0x0a,
     869,   14,   14,   14, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_AppController[] = {
    "AppController\0\0theCurrentFile\0"
    "currentFile(QString)\0theMessage\0"
    "messageToBeDisplayed(QString)\0"
    "restoreCurs()\0setCurs()\0updateSignal()\0"
    "abortSimulation()\0BCPressed()\0"
    "caseInfoPressed()\0customizeGraph()\0"
    "event\0closeEvent(QCloseEvent*)\0cookie\0"
    "closeResultsView(QString)\0cookie,elementData\0"
    "dataConfirAndClose(QString,QString)\0"
    "dataConfirmed(QString,QString)\0"
    "elementRequest\0dataRequest(QPoint)\0"
    "dockClosed()\0errorFromExternal(QProcess::ProcessError)\0"
    "generateMesh()\0goMeshing()\0goCustomizing()\0"
    "graphHasBeenCustomized()\0importBC()\0"
    "importMesh()\0importNetwork()\0"
    "importResults()\0initNewCase()\0"
    "maximizeApp()\0minimizeApp()\0"
    "meshHasBeenGenerated()\0newNetwork()\0"
    "openNetwork()\0resultsDockClosed()\0"
    "bool\0save()\0saveAs()\0theFName,theWDir\0"
    "setFNameAndWDir(QString,QString)\0"
    "setPreferences()\0showResults(QPoint)\0"
    "showResultsDock()\0simulateGraph()\0,\0"
    "simulationHasBeenPerformed(int,QProcess::ExitStatus)\0"
    "standardOutputFromExternal()\0"
};

const QMetaObject AppController::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_AppController,
      qt_meta_data_AppController, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &AppController::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *AppController::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *AppController::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_AppController))
        return static_cast<void*>(const_cast< AppController*>(this));
    return QObject::qt_metacast(_clname);
}

int AppController::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: currentFile((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: messageToBeDisplayed((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: restoreCurs(); break;
        case 3: setCurs(); break;
        case 4: updateSignal(); break;
        case 5: abortSimulation(); break;
        case 6: BCPressed(); break;
        case 7: caseInfoPressed(); break;
        case 8: customizeGraph(); break;
        case 9: closeEvent((*reinterpret_cast< QCloseEvent*(*)>(_a[1]))); break;
        case 10: closeResultsView((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 11: dataConfirAndClose((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 12: dataConfirmed((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 13: dataRequest((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 14: dockClosed(); break;
        case 15: errorFromExternal((*reinterpret_cast< QProcess::ProcessError(*)>(_a[1]))); break;
        case 16: generateMesh(); break;
        case 17: goMeshing(); break;
        case 18: goCustomizing(); break;
        case 19: graphHasBeenCustomized(); break;
        case 20: importBC(); break;
        case 21: importMesh(); break;
        case 22: importNetwork(); break;
        case 23: importResults(); break;
        case 24: initNewCase(); break;
        case 25: maximizeApp(); break;
        case 26: minimizeApp(); break;
        case 27: meshHasBeenGenerated(); break;
        case 28: newNetwork(); break;
        case 29: openNetwork(); break;
        case 30: resultsDockClosed(); break;
        case 31: { bool _r = save();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 32: { bool _r = saveAs();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 33: setFNameAndWDir((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 34: setPreferences(); break;
        case 35: showResults((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 36: showResultsDock(); break;
        case 37: simulateGraph(); break;
        case 38: simulationHasBeenPerformed((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QProcess::ExitStatus(*)>(_a[2]))); break;
        case 39: standardOutputFromExternal(); break;
        default: ;
        }
        _id -= 40;
    }
    return _id;
}

// SIGNAL 0
void AppController::currentFile(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void AppController::messageToBeDisplayed(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void AppController::restoreCurs()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}

// SIGNAL 3
void AppController::setCurs()
{
    QMetaObject::activate(this, &staticMetaObject, 3, 0);
}

// SIGNAL 4
void AppController::updateSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 4, 0);
}
QT_END_MOC_NAMESPACE
