/********************************************************************************
** Form generated from reading UI file 'dialog.ui'
**
** Created: Fri Jun 10 15:19:11 2011
**      by: Qt User Interface Compiler version 4.7.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QLabel *pythonLabel;
    QLabel *pythonLocation;
    QLabel *pyNSLabel;
    QLabel *pyNSLocation;
    QLineEdit *pythonEdit;
    QDialogButtonBox *buttonBox;
    QPushButton *pythonChoose;
    QPushButton *pyNSChoose;
    QLineEdit *pyNSEdit;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QString::fromUtf8("Dialog"));
        Dialog->resize(550, 300);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(Dialog->sizePolicy().hasHeightForWidth());
        Dialog->setSizePolicy(sizePolicy);
        Dialog->setMinimumSize(QSize(400, 300));
        pythonLabel = new QLabel(Dialog);
        pythonLabel->setObjectName(QString::fromUtf8("pythonLabel"));
        pythonLabel->setGeometry(QRect(30, 20, 62, 16));
        QFont font;
        font.setPointSize(14);
        pythonLabel->setFont(font);
        pythonLocation = new QLabel(Dialog);
        pythonLocation->setObjectName(QString::fromUtf8("pythonLocation"));
        pythonLocation->setGeometry(QRect(30, 52, 62, 16));
        QFont font1;
        font1.setPointSize(10);
        pythonLocation->setFont(font1);
        pyNSLabel = new QLabel(Dialog);
        pyNSLabel->setObjectName(QString::fromUtf8("pyNSLabel"));
        pyNSLabel->setGeometry(QRect(30, 120, 181, 21));
        pyNSLabel->setFont(font);
        pyNSLocation = new QLabel(Dialog);
        pyNSLocation->setObjectName(QString::fromUtf8("pyNSLocation"));
        pyNSLocation->setGeometry(QRect(30, 152, 62, 16));
        pyNSLocation->setFont(font1);
        pythonEdit = new QLineEdit(Dialog);
        pythonEdit->setObjectName(QString::fromUtf8("pythonEdit"));
        pythonEdit->setGeometry(QRect(90, 51, 341, 20));
        buttonBox = new QDialogButtonBox(Dialog);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setEnabled(true);
        buttonBox->setGeometry(QRect(370, 250, 164, 32));
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        pythonChoose = new QPushButton(Dialog);
        pythonChoose->setObjectName(QString::fromUtf8("pythonChoose"));
        pythonChoose->setGeometry(QRect(440, 46, 101, 32));
        pyNSChoose = new QPushButton(Dialog);
        pyNSChoose->setObjectName(QString::fromUtf8("pyNSChoose"));
        pyNSChoose->setGeometry(QRect(440, 147, 101, 32));
        pyNSEdit = new QLineEdit(Dialog);
        pyNSEdit->setObjectName(QString::fromUtf8("pyNSEdit"));
        pyNSEdit->setGeometry(QRect(90, 150, 341, 20));

        retranslateUi(Dialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), Dialog, SLOT(okPressed()));
        QObject::connect(buttonBox, SIGNAL(rejected()), Dialog, SLOT(cancelPressed()));
        QObject::connect(pythonChoose, SIGNAL(clicked()), Dialog, SLOT(pythonChoosePressed()));
        QObject::connect(pyNSChoose, SIGNAL(clicked()), Dialog, SLOT(pyNSChoosePressed()));

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QApplication::translate("Dialog", "Preferences...", 0, QApplication::UnicodeUTF8));
        pythonLabel->setText(QApplication::translate("Dialog", "Python", 0, QApplication::UnicodeUTF8));
        pythonLocation->setText(QApplication::translate("Dialog", "Location:", 0, QApplication::UnicodeUTF8));
        pyNSLabel->setText(QApplication::translate("Dialog", "pyNS", 0, QApplication::UnicodeUTF8));
        pyNSLocation->setText(QApplication::translate("Dialog", "Location:", 0, QApplication::UnicodeUTF8));
        pythonChoose->setText(QApplication::translate("Dialog", "Choose...", 0, QApplication::UnicodeUTF8));
        pyNSChoose->setText(QApplication::translate("Dialog", "Choose...", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
