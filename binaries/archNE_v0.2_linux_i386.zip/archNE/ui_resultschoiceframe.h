/********************************************************************************
** Form generated from reading UI file 'resultschoiceframe.ui'
**
** Created: Fri Jun 10 15:19:11 2011
**      by: Qt User Interface Compiler version 4.7.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RESULTSCHOICEFRAME_H
#define UI_RESULTSCHOICEFRAME_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QFrame>
#include <QtGui/QHeaderView>
#include <QtGui/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_ResultsChoiceFrame
{
public:
    QVBoxLayout *verticalLayout;
    QComboBox *resultsCombo;

    void setupUi(QFrame *ResultsChoiceFrame)
    {
        if (ResultsChoiceFrame->objectName().isEmpty())
            ResultsChoiceFrame->setObjectName(QString::fromUtf8("ResultsChoiceFrame"));
        ResultsChoiceFrame->resize(200, 200);
        ResultsChoiceFrame->setFrameShape(QFrame::NoFrame);
        ResultsChoiceFrame->setFrameShadow(QFrame::Raised);
        verticalLayout = new QVBoxLayout(ResultsChoiceFrame);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        resultsCombo = new QComboBox(ResultsChoiceFrame);
        resultsCombo->setObjectName(QString::fromUtf8("resultsCombo"));

        verticalLayout->addWidget(resultsCombo);


        retranslateUi(ResultsChoiceFrame);

        QMetaObject::connectSlotsByName(ResultsChoiceFrame);
    } // setupUi

    void retranslateUi(QFrame *ResultsChoiceFrame)
    {
        ResultsChoiceFrame->setWindowTitle(QApplication::translate("ResultsChoiceFrame", "Frame", 0, QApplication::UnicodeUTF8));
        resultsCombo->clear();
        resultsCombo->insertItems(0, QStringList()
         << QApplication::translate("ResultsChoiceFrame", "None", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ResultsChoiceFrame", "Mean Pressure", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ResultsChoiceFrame", "Max Pressure", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ResultsChoiceFrame", "Min Pressure", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ResultsChoiceFrame", "Mean Flow", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ResultsChoiceFrame", "Max Flow", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ResultsChoiceFrame", "Min Flow", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ResultsChoiceFrame", "Mean WSS", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ResultsChoiceFrame", "Max WSS", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ResultsChoiceFrame", "Min WSS", 0, QApplication::UnicodeUTF8)
        );
    } // retranslateUi

};

namespace Ui {
    class ResultsChoiceFrame: public Ui_ResultsChoiceFrame {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RESULTSCHOICEFRAME_H
