/********************************************************************************
** Form generated from reading UI file 'resultsgroupbox.ui'
**
** Created: Fri Jun 10 15:19:11 2011
**      by: Qt User Interface Compiler version 4.7.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RESULTSGROUPBOX_H
#define UI_RESULTSGROUPBOX_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QSplitter>
#include <QtGui/QTabWidget>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include <resultschoiceframe.h>

QT_BEGIN_NAMESPACE

class Ui_ResultsGroupBox
{
public:
    QVBoxLayout *vboxLayout;
    QSplitter *splitter;
    QTabWidget *resTabs;
    ResultsChoiceFrame *resultsChoiceFrame;

    void setupUi(QWidget *ResultsGroupBox)
    {
        if (ResultsGroupBox->objectName().isEmpty())
            ResultsGroupBox->setObjectName(QString::fromUtf8("ResultsGroupBox"));
        ResultsGroupBox->resize(330, 496);
        ResultsGroupBox->setStyleSheet(QString::fromUtf8(""));
        vboxLayout = new QVBoxLayout(ResultsGroupBox);
        vboxLayout->setSpacing(0);
        vboxLayout->setContentsMargins(0, 0, 0, 0);
        vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));
        splitter = new QSplitter(ResultsGroupBox);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setFrameShape(QFrame::NoFrame);
        splitter->setOrientation(Qt::Vertical);
        resTabs = new QTabWidget(splitter);
        resTabs->setObjectName(QString::fromUtf8("resTabs"));
        splitter->addWidget(resTabs);
        resultsChoiceFrame = new ResultsChoiceFrame(splitter);
        resultsChoiceFrame->setObjectName(QString::fromUtf8("resultsChoiceFrame"));
        resultsChoiceFrame->setGeometry(QRect(0, 0, 330, 30));
        splitter->addWidget(resultsChoiceFrame);

        vboxLayout->addWidget(splitter);


        retranslateUi(ResultsGroupBox);

        QMetaObject::connectSlotsByName(ResultsGroupBox);
    } // setupUi

    void retranslateUi(QWidget *ResultsGroupBox)
    {
        Q_UNUSED(ResultsGroupBox);
    } // retranslateUi

};

namespace Ui {
    class ResultsGroupBox: public Ui_ResultsGroupBox {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RESULTSGROUPBOX_H
