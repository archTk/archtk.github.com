/****************************************************************************
** Meta object code from reading C++ file 'infodialog.h'
**
** Created: Fri Jun 10 15:20:25 2011
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../archNE/infodialog.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'infodialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_InfoDialog[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x05,
      30,   11,   11,   11, 0x05,
      44,   11,   11,   11, 0x05,
      58,   11,   11,   11, 0x05,
      85,   11,   11,   11, 0x05,

 // slots: signature, parameters, type, tag, flags
     107,   11,   11,   11, 0x0a,
     135,  129,   11,   11, 0x0a,
     155,  129,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_InfoDialog[] = {
    "InfoDialog\0\0abortSimulation()\0"
    "minimizeApp()\0maximizeApp()\0"
    "mouseEnteredInInfoDialog()\0"
    "mouseLeftInfoDialog()\0abortButtonReleased()\0"
    "event\0enterEvent(QEvent*)\0leaveEvent(QEvent*)\0"
};

const QMetaObject InfoDialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_InfoDialog,
      qt_meta_data_InfoDialog, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &InfoDialog::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *InfoDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *InfoDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_InfoDialog))
        return static_cast<void*>(const_cast< InfoDialog*>(this));
    return QDialog::qt_metacast(_clname);
}

int InfoDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: abortSimulation(); break;
        case 1: minimizeApp(); break;
        case 2: maximizeApp(); break;
        case 3: mouseEnteredInInfoDialog(); break;
        case 4: mouseLeftInfoDialog(); break;
        case 5: abortButtonReleased(); break;
        case 6: enterEvent((*reinterpret_cast< QEvent*(*)>(_a[1]))); break;
        case 7: leaveEvent((*reinterpret_cast< QEvent*(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void InfoDialog::abortSimulation()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void InfoDialog::minimizeApp()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void InfoDialog::maximizeApp()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}

// SIGNAL 3
void InfoDialog::mouseEnteredInInfoDialog()
{
    QMetaObject::activate(this, &staticMetaObject, 3, 0);
}

// SIGNAL 4
void InfoDialog::mouseLeftInfoDialog()
{
    QMetaObject::activate(this, &staticMetaObject, 4, 0);
}
QT_END_MOC_NAMESPACE
